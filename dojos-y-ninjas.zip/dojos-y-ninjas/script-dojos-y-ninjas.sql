-- crea tres dojos nuevos
INSERT INTO dojos (name)
VALUES	('Luna'),
		('Estrella'),
        ('Espacio');
        
SELECT *
FROM dojos;

-- elimiar los tres dojos que acabas de crear

DELETE FROM dojos
WHERE id = 1;

SELECT *
FROM dojos;

DELETE FROM dojos
WHERE id = 2;

SELECT *
FROM dojos;

DELETE FROM dojos
WHERE id = 3;

SELECT * 
FROM dojos;

-- crea tres dojos

INSERT INTO dojos (name)
VALUES	('Luna'),
		('Estrella'),
        ('Espacio');
        
SELECT *
FROM dojos;

-- crear tres ninjas que pertenezcan al primer dojo

INSERT INTO ninjas (first_name, last_name, age, dojo_id)
VALUES  ('Claudia', 'R', 53, 4),
		('Natalia', 'P', 32, 4),
        ('Alejandra', 'P', 27, 4);
        
SELECT * 
FROM ninjas;

-- crear tres ninjas que pertenezcan al segundo dojo

INSERT INTO ninjas (first_name, last_name, age, dojo_id)
VALUES  ('Sergio', 'P', 62, 5),
		('Felipe', 'P', 34, 5),
        ('Manuel', 'S', 27, 5);
        
SELECT * 
FROM ninjas;

-- crea tres ninjas que pertenezcan al tercer dojo

INSERT INTO ninjas (first_name, last_name, age, dojo_id)
VALUES  ('Enrique', 'C', 7, 6),
		('Alan', 'N', 34, 6),
        ('Miguel', 'A', 27, 6);
        
SELECT * 
FROM ninjas;

-- recupera los ninjas del primer dojo

SELECT *
FROM ninjas WHERE dojo_id = 4;

-- recupera los ninjas del ultomo dojo
SELECT *
FROM ninjas WHERE dojo_id = 6;

-- recupera el dojo del ultimo ninja

SELECT *
FROM ninjas;

SELECT dojos.name
FROM ninjas JOIN dojos
	ON ninjas.dojo_id = dojos.id
WHERE ninjas.id = 9;
